namespace WinZoom;

/// <summary>拡大表示で画面に映す範囲（元画像の切り出し矩形）の計算。</summary>
internal static class ViewGeometry
{
    /// <summary>
    /// カーソル直下のピクセルが実座標と一致するように切り出し矩形を決める。
    ///
    /// 拡大後の画面座標 S に映るのは <c>rect.Left + (S - monitor.Left) / level</c> の位置なので、
    /// S = cursor で元の cursor と一致するよう左上を
    /// <c>cursor - (cursor - monitor 左上) / level</c> に置く。
    /// カーソル位置が動かず周囲が広がる拡大になり、見えている対象と
    /// 実際にクリックされる対象が常に一致する。
    /// カーソルがモニターの端にあるときは矩形も端に接するので、はみ出しは起きない。
    /// </summary>
    public static Native.RECT SourceRect(Native.RECT monitor, Native.POINT cursor, float level)
    {
        int w = (int)Math.Round(monitor.Width / level);
        int h = (int)Math.Round(monitor.Height / level);

        int left = cursor.X - (int)Math.Round((cursor.X - monitor.Left) / level);
        int top = cursor.Y - (int)Math.Round((cursor.Y - monitor.Top) / level);

        // 端での丸め誤差でモニター外を映さないよう念のためクランプする
        left = Math.Clamp(left, monitor.Left, Math.Max(monitor.Left, monitor.Right - w));
        top = Math.Clamp(top, monitor.Top, Math.Max(monitor.Top, monitor.Bottom - h));

        return new Native.RECT { Left = left, Top = top, Right = left + w, Bottom = top + h };
    }
}
