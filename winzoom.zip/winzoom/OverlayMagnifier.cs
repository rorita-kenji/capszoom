namespace WinZoom;

/// <summary>
/// 対象モニター全面にクリック透過のトップモストな拡大鏡ウィンドウを重ねて拡大表示を作る。
///
/// Magnification API のフルスクリーン変換 (<c>MagSetFullscreenTransform</c>) ではなく
/// この方式を使うのは、フルスクリーン変換がデスクトップ全体に効いてしまい、
/// 「カーソルのあるモニターだけ拡大する」ができないため
/// （プライマリで拡大するとセカンダリまで一緒に拡大される）。
/// </summary>
internal sealed class OverlayMagnifier : IDisposable
{
    const string HostClassName = "WinZoomOverlayHost";

    // デリゲートは GC されるとウィンドウプロシージャが壊れるので保持する
    static Native.WndProc? _wndProc;
    static ushort _classAtom;

    IntPtr _host = IntPtr.Zero;
    IntPtr _mag = IntPtr.Zero;
    Native.RECT _bounds;
    bool _visible;
    float _appliedLevel;

    /// <summary>
    /// ウィンドウだけ先に作っておく。生成には実測で 280ms ほどかかるので、
    /// 最初の拡大でこれを踏まないよう起動時に呼んでおく。
    /// </summary>
    public void Prepare() => EnsureWindows();

    /// <summary>指定モニターを覆う拡大表示を、指定の切り出し範囲・倍率で更新する。</summary>
    public void Update(Native.RECT monitor, Native.RECT source, float level)
    {
        if (!EnsureWindows()) return;

        bool moved = !RectEquals(monitor, _bounds);
        if (moved)
        {
            _bounds = monitor;
            Native.SetWindowPos(_host, Native.HWND_TOPMOST,
                monitor.Left, monitor.Top, monitor.Width, monitor.Height,
                Native.SWP_NOACTIVATE | (_visible ? 0 : Native.SWP_NOREDRAW));
            Native.SetWindowPos(_mag, IntPtr.Zero, 0, 0, monitor.Width, monitor.Height,
                Native.SWP_NOACTIVATE);
            _appliedLevel = 0f;
        }

        // 倍率の変更は垂直同期を 1 回余分に待つので、変わったときだけ呼ぶ
        if (Math.Abs(level - _appliedLevel) > 0.0001f)
        {
            var transform = Native.MAGTRANSFORM.Scale(level);
            Native.MagSetWindowTransform(_mag, ref transform);
            _appliedLevel = level;
        }

        Native.MagSetWindowSource(_mag, source);
        Native.InvalidateRect(_mag, IntPtr.Zero, false);

        // 表示は中身を描き込んだあと。先に見せると未描画の 1 フレームがちらつく
        if (!_visible)
        {
            Native.ShowWindow(_host, Native.SW_SHOWNA);
            _visible = true;
        }
    }

    public void Hide()
    {
        if (!_visible) return;
        Native.ShowWindow(_host, Native.SW_HIDE);
        _visible = false;
    }

    bool EnsureWindows()
    {
        if (_mag != IntPtr.Zero) return true;

        IntPtr instance = Native.GetModuleHandle(null);

        if (_classAtom == 0)
        {
            _wndProc = Native.DefWindowProc;
            var wc = new Native.WNDCLASSEX
            {
                cbSize = System.Runtime.InteropServices.Marshal.SizeOf<Native.WNDCLASSEX>(),
                lpfnWndProc = System.Runtime.InteropServices.Marshal.GetFunctionPointerForDelegate(_wndProc),
                hInstance = instance,
                lpszClassName = HostClassName,
            };
            _classAtom = Native.RegisterClassEx(ref wc);
            if (_classAtom == 0) return false;
        }

        // クリックを透過し、フォーカスも奪わない全面オーバーレイ
        _host = Native.CreateWindowEx(
            Native.WS_EX_TOPMOST | Native.WS_EX_LAYERED | Native.WS_EX_TRANSPARENT |
            Native.WS_EX_NOACTIVATE | Native.WS_EX_TOOLWINDOW,
            HostClassName, "WinZoom Overlay", Native.WS_POPUP,
            0, 0, 100, 100, IntPtr.Zero, IntPtr.Zero, instance, IntPtr.Zero);
        if (_host == IntPtr.Zero) return false;

        Native.SetLayeredWindowAttributes(_host, 0, 255, Native.LWA_ALPHA);

        _mag = Native.CreateWindowEx(
            0, Native.WC_MAGNIFIER, "WinZoom Magnifier",
            Native.WS_CHILD | Native.WS_VISIBLE,
            0, 0, 100, 100, _host, IntPtr.Zero, instance, IntPtr.Zero);
        if (_mag == IntPtr.Zero)
        {
            Native.DestroyWindow(_host);
            _host = IntPtr.Zero;
            return false;
        }

        // 自分自身のオーバーレイを拡大元に含めない（含めると映像がループする）
        Native.MagSetWindowFilterList(_mag, Native.MW_FILTERMODE_EXCLUDE, 1, new[] { _host });
        return true;
    }

    static bool RectEquals(Native.RECT a, Native.RECT b) =>
        a.Left == b.Left && a.Top == b.Top && a.Right == b.Right && a.Bottom == b.Bottom;

    public void Dispose()
    {
        if (_mag != IntPtr.Zero) { Native.DestroyWindow(_mag); _mag = IntPtr.Zero; }
        if (_host != IntPtr.Zero) { Native.DestroyWindow(_host); _host = IntPtr.Zero; }
        _visible = false;
    }
}
