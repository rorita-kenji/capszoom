using System.Drawing;
using System.Windows.Forms;

namespace WinZoom;

internal static class Program
{
    static readonly float[] ZoomChoices = { 1.5f, 2.0f, 2.5f, 3.0f, 4.0f };

    [STAThread]
    static void Main()
    {
        // 多重起動するとフックが二重になるので 1 インスタンスに限定する
        using var mutex = new Mutex(true, @"Local\WinZoom.SingleInstance", out bool isNew);
        if (!isNew)
        {
            MessageBox.Show("WinZoom はすでに起動しています。", "WinZoom",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        // PerMonitorV2 DPI 認識。物理ピクセルで座標を扱うために必須
        ApplicationConfiguration.Initialize();

        using var zoom = new ZoomController();
        if (!zoom.Initialize())
        {
            MessageBox.Show("拡大機能 (Magnification API) の初期化に失敗しました。",
                "WinZoom", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        using var hook = new CapsLockHook();

        // フックは専用スレッドで動くので、拡大処理は UI スレッドへ渡してから実行する
        using var marshaller = new Form();
        _ = marshaller.Handle;
        hook.Pressed += () =>
        {
            if (marshaller.IsHandleCreated)
                marshaller.BeginInvoke(zoom.Toggle);
        };

        using var icon = LoadAppIcon();
        using var menu = new ContextMenuStrip();
        using var tray = new NotifyIcon
        {
            Icon = icon,
            Text = Tooltip(zoom.ZoomLevel),
            Visible = true,
            ContextMenuStrip = menu,
        };

        var levelItem = new ToolStripMenuItem("拡大倍率");
        foreach (float level in ZoomChoices)
        {
            float captured = level;
            var item = new ToolStripMenuItem($"{level:0.0} 倍")
            {
                Checked = Math.Abs(level - zoom.ZoomLevel) < 0.01f,
            };
            item.Click += (_, _) =>
            {
                zoom.ZoomLevel = captured;
                foreach (ToolStripMenuItem sibling in levelItem.DropDownItems)
                    sibling.Checked = ReferenceEquals(sibling, item);
                tray.Text = Tooltip(captured);
                if (zoom.IsZoomed)   // 拡大中なら即座に新しい倍率へ
                {
                    zoom.SetZoomed(false);
                    zoom.SetZoomed(true);
                }
            };
            levelItem.DropDownItems.Add(item);
        }

        menu.Items.Add(levelItem);
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("終了", null, (_, _) => Application.Exit());

        // トレイアイコンのダブルクリックでも拡大を切り替えられるようにしておく
        tray.DoubleClick += (_, _) => zoom.Toggle();

        Application.ApplicationExit += (_, _) =>
        {
            tray.Visible = false;
            hook.Dispose();
            zoom.Dispose();   // 拡大を等倍に戻してから終了する
        };

        // フックの設置はメッセージループが回り始めてから行う。
        // ループ開始前に設置すると、それまでに押されたキーの処理が queue に溜まり、
        // 拡大の ON と OFF が打ち消し合って「最初の数回が効かない」状態になる。
        marshaller.BeginInvoke(() =>
        {
            if (!hook.Install())
                MessageBox.Show("キーボードフックの登録に失敗しました。",
                    "WinZoom", MessageBoxButtons.OK, MessageBoxIcon.Error);
        });

        Application.Run();
    }

    /// <summary>
    /// トレイのツールチップ。どのビルドが常駐しているか判別できるよう、
    /// 実行ファイルの更新時刻をビルド時刻として表示する。
    /// </summary>
    static string Tooltip(float level)
    {
        string built = File.GetLastWriteTime(Environment.ProcessPath ?? Application.ExecutablePath)
            .ToString("MM/dd HH:mm");
        return $"WinZoom {level:0.0}倍 (build {built})";
    }

    /// <summary>実行ファイルに埋め込んだ虫眼鏡アイコンを読み込む。</summary>
    static Icon LoadAppIcon()
    {
        using var stream = typeof(Program).Assembly.GetManifestResourceStream("WinZoom.AppIcon.ico");
        return stream is null ? SystemIcons.Application : new Icon(stream);
    }
}
