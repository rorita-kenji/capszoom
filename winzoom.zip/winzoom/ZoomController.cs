namespace WinZoom;

/// <summary>
/// 画面を拡大し、マウスカーソル位置に毎フレーム追従させる。
///
/// 拡大は <see cref="OverlayMagnifier"/> のオーバーレイで行い、
/// カーソルが載っているモニターだけを対象にする。
/// カーソルがモニターをまたいだ場合も毎フレーム判定して自動で追いかける。
/// </summary>
internal sealed class ZoomController : IDisposable
{
    // 追従の更新間隔。オーバーレイの更新呼び出し自体が垂直同期を待って
    // 16.7ms かかる (実測) ので、タイマー側で待たせないよう短くしておく。
    // これで更新は表示のリフレッシュレートに同期した 60fps になる。
    const int TickIntervalMs = 8;

    readonly System.Windows.Forms.Timer _timer = new() { Interval = TickIntervalMs };
    readonly OverlayMagnifier _overlay = new();

    bool _magInitialized;
    float _level = 1f;   // 適用中の倍率。1 なら拡大していない

    /// <summary>CapsLock で切り替える拡大倍率。</summary>
    public float ZoomLevel { get; set; } = 2.0f;

    /// <summary>拡大中かどうか。</summary>
    public bool IsZoomed => _level > 1f;

    public event Action<bool>? ZoomStateChanged;

    public bool Initialize()
    {
        _magInitialized = Native.MagInitialize();
        if (_magInitialized)
        {
            // 拡大鏡ウィンドウの生成には 280ms ほどかかる。最初のトグルでこれを踏むと
            // UI スレッドが止まって 1 回目が効かなかったように見えるので、先に作っておく。
            _overlay.Prepare();

            // フルスクリーン変換は使わないが、これを使っていた旧版が強制終了され
            // 画面を拡大したまま残していた場合の復旧のため一度だけ等倍に戻す。
            Native.MagSetFullscreenTransform(1f, 0, 0);
            _timer.Tick += OnTick;
        }
        return _magInitialized;
    }

    public void Toggle() => SetZoomed(!IsZoomed);

    public void SetZoomed(bool zoomed)
    {
        if (!_magInitialized || zoomed == IsZoomed) return;

        _level = zoomed ? ZoomLevel : 1f;
        if (zoomed)
        {
            Apply();        // 待たずにその場で拡大する
            _timer.Start();
        }
        else
        {
            _timer.Stop();
            _overlay.Hide();
        }
        ZoomStateChanged?.Invoke(zoomed);
    }

    void OnTick(object? sender, EventArgs e) => Apply();

    /// <summary>カーソルのあるモニターに拡大表示を適用する。</summary>
    void Apply()
    {
        if (!IsZoomed || !Native.GetCursorPos(out var cursor)) return;

        // 毎フレーム更新する。カーソルが止まっていても、拡大元の内容
        // (動画やカーソル点滅など) を追いかけるために更新は止めない。
        var mon = Native.GetMonitorFromPoint(cursor).Rect;
        _overlay.Update(mon, ViewGeometry.SourceRect(mon, cursor, _level), _level);
    }

    public void Dispose()
    {
        _timer.Stop();
        _timer.Dispose();
        if (_magInitialized)
        {
            _overlay.Hide();                            // 拡大したまま終了しない
            _overlay.Dispose();
            Native.MagUninitialize();
            _magInitialized = false;
        }
    }
}
