using System.Diagnostics;
using System.Windows.Forms;

namespace WinZoom;

/// <summary>
/// CapsLock / 英数 キーを横取りする低レベルキーボードフック。
/// 単独押しは OS に渡さず <see cref="Pressed"/> を発火する。
/// 修飾キーを併用した場合は素通しするので、
/// JIS キーボード本来の Shift + 英数 による英大文字ロックはそのまま使える。
///
/// フックは専用スレッドに専用のメッセージループを立てて設置する。
/// 低レベルフックのコールバックは設置したスレッドがメッセージを処理して初めて呼ばれるため、
/// UI スレッドに載せると (1) メッセージループが回り出すまでの起動直後、
/// (2) 拡大 API の呼び出しで UI スレッドが詰まっている間、キーを取りこぼす。
/// <see cref="Pressed"/> はこの専用スレッド上で発火するので、購読側で UI スレッドへ渡すこと。
/// </summary>
internal sealed class CapsLockHook : IDisposable
{
    /// <summary>連続発火を防ぐ間隔。押しっぱなしのオートリピート対策も兼ねる。</summary>
    const double DebounceMs = 200;

    // デリゲートは GC されるとフックが壊れるのでフィールドで保持する
    readonly Native.LowLevelKeyboardProc _proc;
    readonly Stopwatch _clock = Stopwatch.StartNew();
    IntPtr _hook = IntPtr.Zero;
    Thread? _thread;
    ApplicationContext? _context;
    double _lastFiredMs = double.NegativeInfinity;

    /// <summary>
    /// 英数キー（JIS 配列）かどうか。true なら Shift の有無を仮想キーコードだけで判定できる。
    /// </summary>
    bool _eisuKey;

    public event Action? Pressed;

    public CapsLockHook() => _proc = HookProc;

    public bool Install()
    {
        // JIS 配列ではスキャンコード 0x3A が VK_OEM_ATTN に割り当てられている。
        // この配列では Shift 併用時だけ VK_CAPITAL に解決されるので、
        // 届いた仮想キーコードを見れば Shift の有無が確定する。
        _eisuKey = Native.MapVirtualKeyEx(Native.SC_CAPSLOCK, Native.MAPVK_VSC_TO_VK_EX,
                                          Native.GetKeyboardLayout(0)) == Native.VK_OEM_ATTN;

        var installed = new ManualResetEventSlim();
        _thread = new Thread(() =>
        {
            _hook = Native.SetWindowsHookEx(
                Native.WH_KEYBOARD_LL, _proc, Native.GetModuleHandle(null), 0);
            installed.Set();
            if (_hook != IntPtr.Zero)
                Application.Run(_context = new ApplicationContext());   // このスレッド専用のループ
        })
        {
            IsBackground = true,
            Name = "WinZoom keyboard hook",
        };
        _thread.SetApartmentState(ApartmentState.STA);
        _thread.Start();
        installed.Wait();
        return _hook != IntPtr.Zero;
    }

    IntPtr HookProc(int nCode, IntPtr wParam, IntPtr lParam)
    {
        if (nCode >= 0)
        {
            var info = System.Runtime.InteropServices.Marshal
                .PtrToStructure<Native.KBDLLHOOKSTRUCT>(lParam);

            if (IsCapsLockKey(info) && !PassThrough(info))
            {
                int msg = (int)wParam;
                if (msg is Native.WM_KEYDOWN or Native.WM_SYSKEYDOWN)
                {
                    // キーアップの受信を前提にした状態を持たない。
                    // 英数キーは環境によってキーアップが別のコードで来たり届かなかったりするため、
                    // ラッチで押下中を管理すると一度きりしか反応しなくなる。
                    double now = _clock.Elapsed.TotalMilliseconds;
                    if (now - _lastFiredMs >= DebounceMs)
                    {
                        _lastFiredMs = now;
                        Pressed?.Invoke();
                    }
                    return 1;         // OS に渡さない = CapsLock 状態は変化しない
                }
                if (msg is Native.WM_KEYUP or Native.WM_SYSKEYUP)
                    return 1;
            }
        }
        return Native.CallNextHookEx(_hook, nCode, wParam, lParam);
    }

    /// <summary>
    /// 物理的な CapsLock キーかどうか。
    /// JIS キーボードの「英数」キーは単独押しだと VK_CAPITAL ではなく VK_OEM_ATTN (0xF0) を送るため、
    /// 仮想キーコードではなくスキャンコード 0x3A（CapsLock の物理位置）を主な判定に使う。
    /// </summary>
    static bool IsCapsLockKey(Native.KBDLLHOOKSTRUCT info) =>
        info.scanCode == Native.SC_CAPSLOCK ||
        info.vkCode is Native.VK_CAPITAL or Native.VK_OEM_ATTN;

    /// <summary>
    /// OS に渡す（横取りしない）べきキーかどうか。
    ///
    /// Shift の判定に <c>GetAsyncKeyState</c> を使うと、Shift を押した直後や離した直後に
    /// 読み取るタイミング次第で取りこぼしが起きうる。JIS 配列なら
    /// 「VK_CAPITAL で届いた = Shift 併用」がイベント自体に含まれているので、
    /// そちらを使ってタイミング依存をなくす。
    /// </summary>
    bool PassThrough(Native.KBDLLHOOKSTRUCT info)
    {
        // Shift + 英数（本来の英大文字ロック）は押下も解放も一切横取りしない
        if (_eisuKey ? info.vkCode == Native.VK_CAPITAL : IsDown(Native.VK_SHIFT))
            return true;

        // Ctrl / Alt / Win 併用はショートカットとして OS に渡す
        return IsDown(Native.VK_CONTROL) || IsDown(Native.VK_MENU) ||
               IsDown(Native.VK_LWIN) || IsDown(Native.VK_RWIN);
    }

    static bool IsDown(int vk) => (Native.GetAsyncKeyState(vk) & 0x8000) != 0;

    public void Dispose()
    {
        if (_hook != IntPtr.Zero)
        {
            Native.UnhookWindowsHookEx(_hook);
            _hook = IntPtr.Zero;
        }
        _context?.ExitThread();
        _context = null;
        _thread = null;
    }
}
